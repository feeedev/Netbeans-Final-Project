/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package librarymain.libraryproject;

/**
 *
 * @author palat
 */
public class libraData {

    /**
     * @return the formattedDate
     */
    public static String getFormattedDate() {
        return formattedDate;
    }

    /**
     * @param aFormattedDate the formattedDate to set
     */
    public static void setFormattedDate(String aFormattedDate) {
        formattedDate = aFormattedDate;
    }
    // homeJF Data member
    private static String FullName;
    private static String passwordInput;
    private static String userNameInput;
    
    // BorrowFrame Data member
    private static String selectedItemStr;
    private static int indexBK;
    private static String selectedbkName;
    private static String selectedbkAuthor;
    private static String inputbookPhone;
    private static Object selectedItem;
    
    // ReturnFrame Data member
    private static String selectedItemReStr;
    private static String selectedbkReName;
    private static String selectedbkReAuthor;
    private static int indexBKre;
    private static Object selectedItemRe;
    private static String formattedDate;

    /**
     * @return the FullName
     */
    public static String getFullName() {
        return FullName;
    }

    /**
     * @param aFullName the FullName to set
     */
    public static void setFullName(String aFullName) {
        FullName = aFullName;
    }

    /**
     * @return the passwordInput
     */
    public static String getPasswordInput() {
        return passwordInput;
    }

    /**
     * @param aPasswordInput the passwordInput to set
     */
    public static void setPasswordInput(String aPasswordInput) {
        passwordInput = aPasswordInput;
    }

    /**
     * @return the userNameInput
     */
    public static String getUserNameInput() {
        return userNameInput;
    }

    /**
     * @param aUserNameInput the userNameInput to set
     */
    public static void setUserNameInput(String aUserNameInput) {
        userNameInput = aUserNameInput;
    }

    /**
     * @return the selectedItemStr
     */
    public static String getSelectedItemStr() {
        return selectedItemStr;
    }

    /**
     * @param aSelectedItemStr the selectedItemStr to set
     */
    public static void setSelectedItemStr(String aSelectedItemStr) {
        selectedItemStr = aSelectedItemStr;
    }

    /**
     * @return the indexBK
     */
    public static int getIndexBK() {
        return indexBK;
    }

    /**
     * @param aIndexBK the indexBK to set
     */
    public static void setIndexBK(int aIndexBK) {
        indexBK = aIndexBK;
    }

    /**
     * @return the selectedbkName
     */
    public static String getSelectedbkName() {
        return selectedbkName;
    }

    /**
     * @param aSelectedbkName the selectedbkName to set
     */
    public static void setSelectedbkName(String aSelectedbkName) {
        selectedbkName = aSelectedbkName;
    }

    /**
     * @return the selectedbkAuthor
     */
    public static String getSelectedbkAuthor() {
        return selectedbkAuthor;
    }

    /**
     * @param aSelectedbkAuthor the selectedbkAuthor to set
     */
    public static void setSelectedbkAuthor(String aSelectedbkAuthor) {
        selectedbkAuthor = aSelectedbkAuthor;
    }

    /**
     * @return the inputbookPhone
     */
    public static String getInputbookPhone() {
        return inputbookPhone;
    }

    /**
     * @param aInputbookPhone the inputbookPhone to set
     */
    public static void setInputbookPhone(String aInputbookPhone) {
        inputbookPhone = aInputbookPhone;
    }

    /**
     * @return the selectedItem
     */
    public static Object getSelectedItem() {
        return selectedItem;
    }

    /**
     * @param aSelectedItem the selectedItem to set
     */
    public static void setSelectedItem(Object aSelectedItem) {
        selectedItem = aSelectedItem;
    }

    /**
     * @return the selectedItemReStr
     */
    public static String getSelectedItemReStr() {
        return selectedItemReStr;
    }

    /**
     * @param aSelectedItemReStr the selectedItemReStr to set
     */
    public static void setSelectedItemReStr(String aSelectedItemReStr) {
        selectedItemReStr = aSelectedItemReStr;
    }

    /**
     * @return the selectedbkReName
     */
    public static String getSelectedbkReName() {
        return selectedbkReName;
    }

    /**
     * @param aSelectedbkReName the selectedbkReName to set
     */
    public static void setSelectedbkReName(String aSelectedbkReName) {
        selectedbkReName = aSelectedbkReName;
    }

    /**
     * @return the selectedbkReAuthor
     */
    public static String getSelectedbkReAuthor() {
        return selectedbkReAuthor;
    }

    /**
     * @param aSelectedbkReAuthor the selectedbkReAuthor to set
     */
    public static void setSelectedbkReAuthor(String aSelectedbkReAuthor) {
        selectedbkReAuthor = aSelectedbkReAuthor;
    }

    /**
     * @return the indexBKre
     */
    public static int getIndexBKre() {
        return indexBKre;
    }

    /**
     * @param aIndexBKre the indexBKre to set
     */
    public static void setIndexBKre(int aIndexBKre) {
        indexBKre = aIndexBKre;
    }

    /**
     * @return the selectedItemRe
     */
    public static Object getSelectedItemRe() {
        return selectedItemRe;
    }

    /**
     * @param aSelectedItemRe the selectedItemRe to set
     */
    public static void setSelectedItemRe(Object aSelectedItemRe) {
        selectedItemRe = aSelectedItemRe;
    }

}
